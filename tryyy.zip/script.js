    var tablinks = document.getElementsByClassName("tab-links");
    var tabcontents = document.getElementsByClassName("tab-contents");

    function opentab(tabname) {
        for (tablink of tablinks) {
            tablink.classList.remove("active-link");
        }
        for (tabcontent of tabcontents) {
            tabcontent.classList.remove("active-tab");
        }

        event.currentTarget.classList.add("active-link");
        document.getElementById(tabname).classList.add("active-tab");
    }

    var sidemenu = document.getElementById("sidemenu");
    
    function openmenu(){
        sidemenu.style.right = "0";
    }
    function closemenu(){
        sidemenu.style.right = "-200px";
    }

    
    const scriptURL = 'https://script.google.com/macros/s/AKfycbzLVGGHfr9NE6DRzhYLnCS_CslCQgqRP0aoUBbZJ-9gMIpta7OmIjzFXjoL8JphNPSK/exec';
    const form = document.forms['submit-to-google-sheet'];
    const msg = document.getElementById('msg');
    const submitButton = document.querySelector('.btn.btn2');
    
    form.addEventListener('submit', e => {
      e.preventDefault();
    
      // Disable the submit button and change its color
      submitButton.disabled = true;
      submitButton.style.backgroundColor = '#ccc';
      submitButton.style.color = '#888';
    
      fetch(scriptURL, { method: 'POST', body: new FormData(form) })
        .then(response => {
          msg.innerHTML = 'Message sent successfully!';
    
          // Hide the message after 4 seconds
          setTimeout(() => {
            msg.innerHTML = '';
          }, 4000);
    
          // Enable the submit button and change its color back to the original
          submitButton.disabled = false;
          submitButton.style.backgroundColor = '#dec9c5';
          submitButton.style.color = '#000';
    
          form.reset();
        })
        .catch(error => {
          console.error('Error!', error.message);
    
          // Enable the submit button in case of error
          submitButton.disabled = false;
          submitButton.style.backgroundColor = '#dec9c5';
          submitButton.style.color = '#000';
        });
    });
    
    
    
    

